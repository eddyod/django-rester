/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `attendance`;
/*!50001 DROP VIEW IF EXISTS `attendance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `attendance` AS SELECT 
 1 AS `id`,
 1 AS `site_id`,
 1 AS `employee_id`,
 1 AS `employee`,
 1 AS `class_month`,
 1 AS `class_year`,
 1 AS `showed_up`,
 1 AS `no_show`,
 1 AS `monthly_pay`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id_b120cbf9` (`group_id`),
  KEY `auth_group_permissions_permission_id_84c5c92e` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (1,'Can add log entry',1,'add_logentry');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (2,'Can change log entry',1,'change_logentry');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (3,'Can delete log entry',1,'delete_logentry');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (4,'Can view log entry',1,'view_logentry');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (5,'Can add permission',2,'add_permission');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (6,'Can change permission',2,'change_permission');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (7,'Can delete permission',2,'delete_permission');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (8,'Can view permission',2,'view_permission');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (9,'Can add group',3,'add_group');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (10,'Can change group',3,'change_group');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (11,'Can delete group',3,'delete_group');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (12,'Can view group',3,'view_group');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (13,'Can add user',4,'add_user');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (14,'Can change user',4,'change_user');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (15,'Can delete user',4,'delete_user');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (16,'Can view user',4,'view_user');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (17,'Can add content type',5,'add_contenttype');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (18,'Can change content type',5,'change_contenttype');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (19,'Can delete content type',5,'delete_contenttype');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (20,'Can view content type',5,'view_contenttype');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (21,'Can add session',6,'add_session');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (22,'Can change session',6,'change_session');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (23,'Can delete session',6,'delete_session');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (24,'Can view session',6,'view_session');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (25,'Can add Attendance',7,'add_attendance');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (26,'Can change Attendance',7,'change_attendance');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (27,'Can delete Attendance',7,'delete_attendance');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (28,'Can view Attendance',7,'view_attendance');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (29,'Can add Employee',8,'add_employee');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (30,'Can change Employee',8,'change_employee');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (31,'Can delete Employee',8,'delete_employee');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (32,'Can view Employee',8,'view_employee');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (33,'Can add Location',9,'add_location');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (34,'Can change Location',9,'change_location');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (35,'Can delete Location',9,'delete_location');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (36,'Can view Location',9,'view_location');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (37,'Can add Schedule',10,'add_schedule');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (38,'Can change Schedule',10,'change_schedule');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (39,'Can delete Schedule',10,'delete_schedule');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (40,'Can view Schedule',10,'view_schedule');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (41,'Can add Site',11,'add_site');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (42,'Can change Site',11,'change_site');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (43,'Can delete Site',11,'delete_site');
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (44,'Can view Site',11,'view_site');
DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `main_site_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`, `main_site_id`) VALUES (1,'pbkdf2_sha256$120000$0IXqijAje72w$XkC7APRPRIywupy9QKpSxnA7XWsxmvsK4VXJbByPzds=',NULL,1,'eddyod','Fast Eddy','','eddyod@yahoo.com',1,1,'2018-11-11 12:56:59.603770',1);
INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`, `main_site_id`) VALUES (2,'pbkdf2_sha256$120000$r918LEUHjvCl$WTfk9wnXV65RghwLA4dvxtOL5TdPP6gryIS5EXbE79g=',NULL,1,'jason','Racin Jason','','jasonodonnell@yahoo.com',1,1,'2018-11-11 12:57:24.491601',2);
INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`, `main_site_id`) VALUES (3,'pbkdf2_sha256$120000$fmOLXzgTgnpo$q1x+MCm1P6PTfPcU2ArOCeofq7FKDmFa9zIKsPvebKs=',NULL,0,'fasteddy','','','eddy.odonnell@gmail.com',0,1,'2018-11-19 06:11:28.313132',NULL);
DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_user_id_6a12ed8b` (`user_id`),
  KEY `auth_user_groups_group_id_97559544` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_user_id_a95ead1b` (`user_id`),
  KEY `auth_user_user_permissions_permission_id_1fbb5f2c` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (1,'admin','logentry');
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (3,'auth','group');
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (2,'auth','permission');
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (4,'auth','user');
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (5,'contenttypes','contenttype');
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (7,'scheduler','attendance');
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (8,'scheduler','employee');
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (9,'scheduler','location');
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (10,'scheduler','schedule');
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (11,'scheduler','site');
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (6,'sessions','session');
DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (1,'contenttypes','0001_initial','2018-11-11 12:55:54.504903');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (2,'auth','0001_initial','2018-11-11 12:55:58.012148');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (3,'admin','0001_initial','2018-11-11 12:55:58.958270');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (4,'admin','0002_logentry_remove_auto_add','2018-11-11 12:55:59.074624');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (5,'admin','0003_logentry_add_action_flag_choices','2018-11-11 12:55:59.190409');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (6,'contenttypes','0002_remove_content_type_name','2018-11-11 12:55:59.745203');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (7,'auth','0002_alter_permission_name_max_length','2018-11-11 12:56:00.032816');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (8,'auth','0003_alter_user_email_max_length','2018-11-11 12:56:00.376146');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (9,'auth','0004_alter_user_username_opts','2018-11-11 12:56:00.493001');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (10,'auth','0005_alter_user_last_login_null','2018-11-11 12:56:00.782363');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (11,'auth','0006_require_contenttypes_0002','2018-11-11 12:56:00.811968');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (12,'auth','0007_alter_validators_add_error_messages','2018-11-11 12:56:00.926779');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (13,'auth','0008_alter_user_username_max_length','2018-11-11 12:56:01.274992');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (14,'auth','0009_alter_user_last_name_max_length','2018-11-11 12:56:01.611122');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (15,'scheduler','0001_initial','2018-11-11 12:56:05.442395');
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (16,'sessions','0001_initial','2018-11-11 12:56:05.692997');
DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address1` varchar(50) DEFAULT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `postal_code` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `K__employee_site_id` (`site_id`),
  KEY `FK__employee_user_id` (`user_id`),
  CONSTRAINT `FK__employee_site_id` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`),
  CONSTRAINT `FK__employee_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (1,'Gavin Harrison','bonillacarrie@turner-johnson.org','852-618-6267','8963 Lee Lane\nEast Angel, NC 55124',NULL,NULL,NULL,NULL,NULL,1,2,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (2,'Cynthia Martin','olloyd@yahoo.com','688-065-9376','021 Gentry Trace Suite 856\nPort Cindyton, NH 50917',NULL,NULL,NULL,NULL,NULL,1,2,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (3,'Jeffrey Parrish','steven07@hill-kim.com','869-292-0529','61521 Charles Heights Suite 120\nLake James, WA 755',NULL,NULL,NULL,NULL,NULL,1,2,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (4,'April Griffin','parrishmatthew@crane.com','945-876-5175','99875 Walls Unions Suite 814\nPort Briantown, GA 68',NULL,NULL,NULL,NULL,NULL,1,2,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (5,'Justin Price','juarezsarah@christensen-ross.com','203-861-3081','515 Carolyn Flat Suite 581\nDavisview, OR 27697',NULL,NULL,NULL,NULL,NULL,1,2,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (6,'Boozer Randy Young','jonesdiana@jones.com','389-827-9671','108 Gonzalez Greens Suite 825\nOrtizstad, OR 08984',NULL,NULL,NULL,NULL,NULL,1,1,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (7,'Boozer Dustin Martinez','holdenmichele@hotmail.com','495-157-4531','0313 Olivia Summit Apt. 445\nLake Gregorymouth, NJ',NULL,NULL,NULL,NULL,NULL,1,1,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (8,'Boozer Laurie Wheeler','wmiller@glenn.info','448-313-5076','4727 Donna Tunnel\nNguyenmouth, AK 08901',NULL,NULL,NULL,NULL,NULL,1,1,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (9,'Boozer Kevin Ellison','nicholashiggins@hotmail.com','448-676-7878','6820 Lisa Streets Suite 894\nMichaelshire, MS 42879',NULL,NULL,NULL,NULL,NULL,1,1,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (10,'Boozer Steven Jones','robert51@hotmail.com','404-191-1013','1996 Nicole Square Apt. 544\nHillshire, NY 89924',NULL,NULL,NULL,NULL,NULL,1,1,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (11,'Boozer Cameron Bennett','diane02@kelly-johnson.biz','635-710-1761','0799 Oneill Canyon\nWest Michelleborough, NE 30512',NULL,NULL,NULL,NULL,NULL,1,1,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (12,'Boozer Casey Harris','shermanmichael@yahoo.com','692-847-0737','98205 John Common\nEast James, IL 89617',NULL,NULL,NULL,NULL,NULL,1,1,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (13,'Boozer Chris Thompson','klee@hotmail.com','848-789-8295','60055 Lauren Shoals\nCarolville, ME 82823',NULL,NULL,NULL,NULL,NULL,1,1,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (14,'Boozer Mackenzie Marshall','david74@gmail.com','824-033-0571','1858 Johnson Stravenue\nGonzalezview, IN 33871',NULL,NULL,NULL,NULL,NULL,1,1,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (15,'Boozer Amber Sanders','vdavis@gmail.com','779-311-3405','2081 Martinez Curve\nAnthonyton, VT 39751',NULL,NULL,NULL,NULL,NULL,1,1,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (16,'Ima Teacher','ima@teacher.com','619-555-3232','123 Main St',NULL,NULL,NULL,NULL,NULL,1,2,NULL);
INSERT INTO `employee` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `active`, `site_id`, `user_id`) VALUES (17,'Hesa Teacher','hesa@teacher.com','215-555-1212','666 Hades Way',NULL,NULL,NULL,NULL,NULL,0,2,NULL);
DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `postal_code` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `latitude` decimal(9,4) DEFAULT NULL,
  `longitude` decimal(9,4) DEFAULT NULL,
  `description` longtext,
  `created` datetime(6) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `K__location_site_id` (`site_id`),
  CONSTRAINT `FK__location_site_id` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `location` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `latitude`, `longitude`, `description`, `created`, `active`, `site_id`) VALUES (1,'Bloomsburg State College','buc@buc.edu','555-1212','Bloomsburg PA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-11 12:57:34.000000',1,2);
INSERT INTO `location` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `latitude`, `longitude`, `description`, `created`, `active`, `site_id`) VALUES (2,'Reading Area Community College','racc@racc.edu','215-555-1212','Reading PA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-11 12:57:34.000000',1,2);
INSERT INTO `location` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `latitude`, `longitude`, `description`, `created`, `active`, `site_id`) VALUES (3,'Kutztown Uni','ku@ku.edu','215-555-1212','Kutztown PA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-11 12:57:34.000000',1,2);
INSERT INTO `location` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `latitude`, `longitude`, `description`, `created`, `active`, `site_id`) VALUES (4,'Beer Bar','buc@buc.edu','555-1212','Bloomsburg PA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-11 12:57:34.000000',1,1);
INSERT INTO `location` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `latitude`, `longitude`, `description`, `created`, `active`, `site_id`) VALUES (5,'Marks Bar','racc@racc.edu','215-555-1212','Reading PA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-11 12:57:34.000000',1,1);
INSERT INTO `location` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `latitude`, `longitude`, `description`, `created`, `active`, `site_id`) VALUES (6,'Joes Bar','ku@ku.edu','215-555-1212','Kutztown PA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-11 12:57:34.000000',1,1);
INSERT INTO `location` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `latitude`, `longitude`, `description`, `created`, `active`, `site_id`) VALUES (7,'University of East Anglia','uea@uea.edu','215-555-1212','Norwich England UK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-18 06:25:27.947288',1,2);
INSERT INTO `location` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `latitude`, `longitude`, `description`, `created`, `active`, `site_id`) VALUES (8,'San Diego State University','sdsu@sdsu.edu','619-555-3232','San Diego CA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-18 07:15:48.153949',1,2);
DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL,
  `start` datetime(6) NOT NULL,
  `end` datetime(6) NOT NULL,
  `pay_rate` decimal(20,2) NOT NULL,
  `created` datetime(6) NOT NULL,
  `completed` tinyint(1) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `K__schedule_employee_id` (`employee_id`),
  KEY `K__schedule_location_id` (`location_id`),
  KEY `K__schedule_site_id` (`site_id`),
  CONSTRAINT `FK__schedule_employee_id` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `FK__schedule_location` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK__schedule_site_id` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (1,'2018-11-18 06:45:00.000000','2018-11-18 07:45:00.000000',11.00,'2018-11-18 06:46:11.406891',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (2,'2018-11-19 09:00:00.000000','2018-11-19 10:00:00.000000',13.00,'2018-11-18 07:17:58.957842',1,17,3,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (3,'2019-10-21 15:30:40.000000','2019-10-21 16:30:40.000000',33.00,'2018-11-18 07:36:17.104324',1,3,1,1);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (4,'2020-05-19 21:12:20.000000','2020-05-19 22:12:20.000000',37.00,'2018-11-18 07:36:17.562548',1,11,4,1);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (5,'2019-08-21 10:37:19.000000','2019-08-21 11:37:19.000000',27.00,'2018-11-18 07:38:43.517838',1,7,4,1);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (6,'2020-04-18 16:12:55.000000','2020-04-18 17:12:55.000000',16.00,'2018-11-18 07:38:43.976010',1,8,4,1);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (7,'2019-05-10 20:00:40.000000','2019-05-10 21:00:40.000000',20.00,'2018-11-18 07:39:40.058349',1,6,8,1);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (8,'2020-09-27 08:07:03.000000','2020-09-27 09:07:03.000000',34.00,'2018-11-18 07:39:40.505686',1,17,1,1);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (9,'2020-07-19 08:19:03.000000','2020-07-19 09:19:03.000000',40.00,'2018-11-18 07:40:12.351030',1,5,1,1);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (10,'2020-05-20 12:32:13.000000','2020-05-20 13:32:13.000000',18.00,'2018-11-18 07:40:12.801936',1,15,2,1);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (11,'2018-11-21 09:00:00.000000','2018-11-21 10:00:00.000000',100.00,'2018-11-18 07:43:57.435098',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (12,'2018-12-04 09:00:00.000000','2018-12-04 10:00:00.000000',100.00,'2018-11-18 07:43:57.575010',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (13,'2018-11-26 09:00:00.000000','2018-11-26 10:00:00.000000',100.00,'2018-11-18 07:43:57.928926',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (14,'2018-11-20 09:00:00.000000','2018-11-20 10:00:00.000000',100.00,'2018-11-18 07:43:58.093206',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (15,'2018-11-19 09:00:00.000000','2018-11-19 10:00:00.000000',100.00,'2018-11-18 07:43:58.135687',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (16,'2018-12-12 09:00:00.000000','2018-12-12 10:00:00.000000',100.00,'2018-11-18 07:43:58.282633',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (17,'2018-12-18 09:00:00.000000','2018-12-18 10:00:00.000000',100.00,'2018-11-18 07:43:58.818324',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (18,'2018-12-24 09:00:00.000000','2018-12-24 10:00:00.000000',100.00,'2018-11-18 07:43:59.131658',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (19,'2018-12-26 09:00:00.000000','2018-12-26 10:00:00.000000',100.00,'2018-11-18 07:43:59.358965',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (20,'2018-12-11 09:00:00.000000','2018-12-11 10:00:00.000000',100.00,'2018-11-18 07:43:59.461309',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (21,'2018-12-03 09:00:00.000000','2018-12-03 10:00:00.000000',100.00,'2018-11-18 07:43:59.543058',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (22,'2018-12-17 09:00:00.000000','2018-12-17 10:00:00.000000',100.00,'2018-11-18 07:43:59.529523',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (23,'2018-11-28 09:00:00.000000','2018-11-28 10:00:00.000000',100.00,'2018-11-18 07:44:00.190498',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (24,'2018-12-19 09:00:00.000000','2018-12-19 10:00:00.000000',100.00,'2018-11-18 07:44:00.556614',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (25,'2018-12-10 09:00:00.000000','2018-12-10 10:00:00.000000',100.00,'2018-11-18 07:44:00.627605',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (26,'2018-11-27 09:00:00.000000','2018-11-27 10:00:00.000000',100.00,'2018-11-18 07:44:00.774604',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (27,'2018-12-25 09:00:00.000000','2018-12-25 10:00:00.000000',100.00,'2018-11-18 07:44:00.917880',1,4,1,2);
INSERT INTO `schedule` (`id`, `start`, `end`, `pay_rate`, `created`, `completed`, `employee_id`, `location_id`, `site_id`) VALUES (28,'2018-12-05 09:00:00.000000','2018-12-05 10:00:00.000000',100.00,'2018-11-18 07:44:01.123823',1,4,1,2);
DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address1` varchar(50) DEFAULT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `postal_code` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `created` datetime(6) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `K__site_owner_id` (`owner_id`),
  CONSTRAINT `FK__site_owner_id` FOREIGN KEY (`owner_id`) REFERENCES `auth_user` (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `site` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `created`, `active`, `owner_id`) VALUES (1,'Fast Eddys Bar and Grill','eddyod@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-11 12:57:34.000000',1,1);
INSERT INTO `site` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `created`, `active`, `owner_id`) VALUES (2,'Premier English','jason@jason.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-11 12:57:34.000000',1,2);
INSERT INTO `site` (`id`, `name`, `email`, `phone`, `address1`, `address2`, `city`, `postal_code`, `province`, `country`, `created`, `active`, `owner_id`) VALUES (3,'Joes Bar and Grill','joe@ucsd.edu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-11-12 10:23:13.105093',1,1);
DROP TABLE IF EXISTS `user_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_site` (
  `id` int(11) NOT NULL,
  `auth_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `K__user_site_auth` (`auth_id`),
  KEY `K__user_site_site` (`site_id`),
  CONSTRAINT `FK__user_site_auth_id` FOREIGN KEY (`auth_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `FK__user_site_site_id` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `user_site` (`id`, `auth_id`, `site_id`) VALUES (1,2,2);
INSERT INTO `user_site` (`id`, `auth_id`, `site_id`) VALUES (2,1,1);
/*!50001 DROP VIEW IF EXISTS `attendance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`eddyod`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `attendance` AS select `s`.`id` AS `id`,`si`.`id` AS `site_id`,`e`.`id` AS `employee_id`,`e`.`name` AS `employee`,month(`s`.`start`) AS `class_month`,year(`s`.`start`) AS `class_year`,sum((case when (`s`.`completed` = 1) then 1 else 0 end)) AS `showed_up`,sum((case when (`s`.`completed` = 0) then 1 else 0 end)) AS `no_show`,(sum((case when (`s`.`completed` = 1) then 1 else 0 end)) * `s`.`pay_rate`) AS `monthly_pay` from ((`schedule` `s` join `employee` `e` on((`s`.`employee_id` = `e`.`id`))) join `site` `si` on((`e`.`site_id` = `si`.`id`))) group by `si`.`id`,`e`.`id`,`e`.`name`,`class_month`,`class_year` order by `class_year`,`class_month`,`e`.`name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

